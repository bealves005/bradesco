<?php 
session_start();
require('../includes/validarLogado.php');

echo "Olá, seja bem-vindo: ".$_SESSION['logado'];
echo "<br><a href='../acoes/logout.php'>Sair do Sistema</a>";

?>