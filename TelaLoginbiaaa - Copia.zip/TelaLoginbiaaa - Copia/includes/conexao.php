<?php 

//CONECTAR COM O SERVIDOR
$conn = mysqli_connect('localhost', 'root', '');

if($conn){
    //CONECTA COM O BD
    mysqli_select_db($conn,'crudbradesco');
}else{+
    die('ERRO AO CONECTAR OA BD');
}

?>