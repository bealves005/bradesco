<?php 

if(!isset($_SESSION['logado'])){
    echo "
        <script>
            alert('Ops! Faça login para continuar');
            location.href='../';
        </script>
    ";
}
?>