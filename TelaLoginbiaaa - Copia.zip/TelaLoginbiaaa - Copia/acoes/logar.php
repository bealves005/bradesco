<?php   
require('../includes/conexao.php');

$email = $_POST['email'];
$senha = $_POST['senha'];

$sql = "SELECT * 
        FROM login1
        WHERE 
        email = '$email' and 
        senha = '$senha'";

$totalRegistros = mysqli_query($conn, $sql);

if($totalRegistros->num_rows > 0){
    $result = mysqli_query($conn, $sql);
    While($registro = mysqli_fetch_assoc($result)){
        $emailLogado = $registro['email'];   
        $nome = $registro['nome'];
        
    }
    
    session_start();//INICIANDO O SERVIÇO DE SESSÃO
      
      $_SESSION['logado'] = true;
      $_SESSION['email'] = $emailLogado;
      $_SESSION['nome'] = $nome;

      echo "
      <script>
         
          location.href='../admin/principal.php';
      </script>
  ";
}else{

    echo "
        <script>
            alert('Ops! Os dados informados estão incorretos');
            location.href='../';
        </script>
    ";
}
?>