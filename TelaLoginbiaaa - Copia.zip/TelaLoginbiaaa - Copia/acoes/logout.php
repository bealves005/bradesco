<?php 

session_start();

session_unset();//LIMPANDO OS DADOS DA SESSÃO

session_destroy();//destuindo a sessão

echo "
    <script>
        location.href='../';
    </script>

";

?>