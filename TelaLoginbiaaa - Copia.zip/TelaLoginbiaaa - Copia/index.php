

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BRADESCO</title>
    <link rel="stylesheet" type="text/css" href="assets/style.css" />
</head>

<body>


    
    <div class="login-wrap">
        <div class="login-html">
            <input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Entrar</label>
            <input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Cadastre-se</label>
            <div class="login-form">
                <div class="sign-in-htm">

                    <form action="acoes/logar.php" method="post">
                    <div class="group">


                        <label for="user" class="label">Email</label>
                        <input id="user" name="email" type="text" class="input">
                    </div>
                    <div class="group">
                        <label for="pass" class="label">Senha</label>
                        <input id="pass" name= "senha" type="password" class="input" data-type="password">
                    </div>
                </form>
                    <div class="group">
                        <input id="check" type="checkbox" class="check" checked>
                        <label for="check"><span class="icon"></span> Mantenha-me conectado</label>
                    </div>
                    <div class="group">
                        <input type="submit" class="button" value="Entrar">
                    </div>
                
                    <div class="hr"></div>
                    <div class="foot-lnk">
                        <a href="#forgot">Esqueceu a senha?</a>
                    </div>
                </div>
                <div class="sign-up-htm">
                    <div class="group">
                        <label for="user" class="label">Nome</label>
                        <input id="user" type="text" class="input">
                    </div>
                    <div class="group">
                        <label for="pass" class="label">Email</label>
                        <input id="pass" type="text" class="input">
                    </div>
                    <div class="group">
                        <label for="pass" class="label">Senha</label>
                        <input id="pass" type="password" class="input" data-type="password">
                    </div>
                    <div class="group">
                        <label for="pass" class="label">Repita a senha</label>
                        <input id="pass" type="password" class="input" data-type="password">
                    </div>
                   
                    <div class="group">
                        <input type="submit" class="button" value="Cadastre-se">
                    </div>
                    <div class="hr"></div>
                    <div class="foot-lnk">


                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>

